# Warp-O-Texture — Web

A browser port of the Warp-O-Texture `.tex` archive viewer/editor. Reads the
same reverse-engineered format as the desktop app (`TexArchive.h`/`.cpp`),
lets you preview entries with the same default orientation correction
(`ImageTransform.h`), import a replacement image for any frame (auto-scaled
to that frame's resolution), export a frame as PNG, and save the edited
archive back out as a `.tex` file. Everything runs client-side — no server,
no build step, no dependencies.

## Files

- `index.html` — markup + styles
- `app.js` — all application logic (the `.tex` parser/writer, the view
  transform math, and the UI wiring)

## Running it locally

Just open `index.html` in a browser. No build step needed.

## Publishing on GitHub Pages

1. Create a new repo (or use an existing one) and push these two files to it
   — `index.html` and `app.js` — at the repo root (or in a `/docs` folder,
   your choice).
2. On GitHub: **Settings → Pages** → under "Build and deployment", set
   **Source** to "Deploy from a branch", pick the branch (e.g. `main`) and
   the folder (`/root` or `/docs`, matching where you put the files).
3. Save. GitHub will publish it at
   `https://<your-username>.github.io/<repo-name>/` within a minute or two.

That's it — `index.html` automatically loads `app.js` via a relative
`<script src="app.js">` tag, so as long as both files sit in the same
folder on Pages it'll work with no further configuration.
